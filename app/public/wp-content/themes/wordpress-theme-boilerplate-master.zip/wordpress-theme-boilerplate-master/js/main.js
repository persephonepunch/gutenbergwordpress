(function(window, $) {
  // REMOVE IF NOT USING 
}(this, this.jQuery));