Hi there,

You have recieved an online request from <?php echo $mail['name'] ?>

<?php echo $mail_message ?>
