<?php

// Include and register widgets
// include_once 'widgets/foo.php';
// add_action('widgets_init', create_function('', 'register_widget("foo_widget");'));