<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/" role="search">
	<input type="text" name="s" id="s"  placeholder="<?php _e('Search', 'theme_text_domain'); ?>">
</form>
